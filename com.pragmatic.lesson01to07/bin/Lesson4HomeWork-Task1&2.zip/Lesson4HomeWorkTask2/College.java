package Lesson4HomeWorkTask2;

import java.util.Arrays;

public class College {

	public static void main(String[] args) {
		StudentGroup Mechanics = new StudentGroup("Mechanics");
		Student Petko = new Student("Petko", "Mechanics", 19);
		Student Ivan = new Student("Ivan", "Mechanics", 20);

		Mechanics.addStudent(Petko);
		Mechanics.addStudent(Ivan);

	}

}
