package Lesson4HomeWorkTask2;

public class StudentGroup {
	String groupSubject;
	Student[] students;
	byte freeSpaces;

	public StudentGroup() {
		students = new Student[5];
		freeSpaces = 5;
	}

	public StudentGroup(String subject) {
		this();
		subject = groupSubject;
	}

	void addStudent(Student s) {
		students = new Student[5];
		int nextIndex = 0;
		this.students[nextIndex] = s;
		++nextIndex;
	}

}
